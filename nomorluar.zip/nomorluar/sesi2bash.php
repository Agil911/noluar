<?php
#Setting / Config
$cmd = "python telemax.py phone_number doge";
$nama_bash = "1.sh";
$max = 100;//Maximal Phone Number In Bash
#System OR Sensitive Syntax
$head = '#!/bin/bash
';

$insert = '
sleep 10
echo " \033[1;36m [ no ]"
';

$bottom = '
';
#Processing Creating Bash
if (file_exists($nama_bash)){
  unlink($nama_bash); //Delete File Lama
  echo "\033[1;32mSukses delete file\033[1;31m : \033[1;0m{$nama_bash}\n";
}
sleep(1);
$folder = "./session"; //Suaikan nama folder
if(!($buka_folder = opendir($folder))) die ("Folder tidak ditemukan!!");
$file_array = array();
while($baca_folder = readdir($buka_folder)){
  $file_array[] = $baca_folder;
}
$jumlah_array = count($file_array);
$aran_file = fopen($nama_bash, 'w');
fwrite($aran_file, $head);
$xx = 0;
$n = 1;
for($i=2; $i<$jumlah_array; $i++){
   if ($max <= $xx){
     $xx = 0;
     fwrite($aran_file, str_replace("no", $n, $insert));
     $n++;
   }
   $nohp = str_replace(['.session','-journal'],['',''], $file_array[$i]);
   echo "\033[1;32mAdd\033[1;31m:\033[1;0m $nohp \033[1;32mto\033[1;31m:\033[1;0m {$nama_bash}\n";
   fwrite($aran_file, str_replace("phone_number", $nohp, $cmd)." &\n");
   $xx++;
}
fwrite($aran_file, $bottom);
fclose($aran_file);
echo "\033[1;32mSukses create file\033[1;31m : \033[1;0m{$nama_bash}\n";
closedir($buka_folder);
sleep(1);
?>
