#!/bin/bash
python telemax.py +13193322121 doge &
python telemax.py +13192462525 doge &
python telemax.py +13194196861 doge &
python telemax.py +13195767808 doge &
python telemax.py +13193278402 doge &
python telemax.py +13193595198 doge &
python telemax.py +13194196796 doge &
python telemax.py +13193136184 doge &
python telemax.py +13198201884 doge &
python telemax.py +13193595048 doge &
python telemax.py +13192384639 doge &
python telemax.py +13193498680 doge &
python telemax.py +13184058010 doge &
python telemax.py +13195198107 doge &
python telemax.py +13194067566 doge &
python telemax.py +13192841820 doge &
python telemax.py +13195190925 doge &
python telemax.py +13192500470 doge &
python telemax.py +13193498776 doge &
python telemax.py +13184058087 doge &

sleep 10
echo " \033[1;36m [ 1 ]"
python telemax.py +13193498540 doge &
python telemax.py +13195757588 doge &
python telemax.py +13192384679 doge &
python telemax.py +13192384702 doge &
python telemax.py +13192384772 doge &
python telemax.py +13192384774 doge &
python telemax.py +13183171750 doge &
python telemax.py +13183705712 doge &
python telemax.py +19852430973 doge &
python telemax.py +13184345618 doge &
python telemax.py +13373578892 doge &
python telemax.py +13183170949 doge &
python telemax.py +13189068226 doge &
python telemax.py +13182237426 doge &
python telemax.py +13187455875 doge &
python telemax.py +13184140692 doge &
python telemax.py +13184068508 doge &
python telemax.py +13372821601 doge &
python telemax.py +12254420947 doge &
python telemax.py +13185362397 doge &

sleep 10
echo " \033[1;36m [ 2 ]"
python telemax.py +13184033895 doge &
python telemax.py +15045410590 doge &
python telemax.py +13184073178 doge &

